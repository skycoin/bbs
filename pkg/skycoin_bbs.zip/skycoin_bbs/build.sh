#!/bin/bash

MAIN_FILE=$GOPATH/src/github.com/skycoin/bbs/cmd/bbsnode/bbsnode.go
go build -o bbsnode.linux $MAIN_FILE
GOOS=windows GOARCH=amd64 go build -o bbsnode.exe $MAIN_FILE
GOOS=darwin  GOARCH=amd64 go build -o bbsnode.darwin $MAIN_FILE
